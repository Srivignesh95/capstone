<!-- includes/footer.php -->
<!-- Footer -->
<footer class="text-center text-muted py-4 border-top">
    &copy; <?php echo date('Y'); ?> EventJoin. All rights reserved.
</footer>
<script src="/capstone/assets/js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.9/main.min.js'></script>

</body>
</html>
