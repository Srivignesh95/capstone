<!-- includes/footer.php -->
<!-- Footer -->
<footer class="text-center text-muted py-4 border-top">
    &copy; <?php echo date('Y'); ?> EventJoin. All rights reserved.
</footer>

</body>
</html>
