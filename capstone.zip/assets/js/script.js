eventClick: function(info) {
    const e = info.event.extendedProps;
    const modalContent = `
        <h5>${info.event.title}</h5>
        <p><strong>Date:</strong> ${info.event.start.toISOString().split('T')[0]}</p>
        <p><strong>Time:</strong> ${e.time}</p>
        <p><strong>Location:</strong> ${e.hall}</p>
        <p>${e.description}</p>
    `;
    document.getElementById('eventModalBody').innerHTML = modalContent;
    new bootstrap.Modal(document.getElementById('eventModal')).show();
}
