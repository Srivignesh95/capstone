<?php
require_once 'config/conn.php';

// Fetch public & approved events
$stmt = $pdo->query("
    SELECT e.id, e.title, e.description, e.event_date, e.event_time, h.name AS hall_name
    FROM events e
    JOIN halls h ON e.hall_id = h.id
    WHERE e.is_public = 1 AND e.status = 'approved'
    ORDER BY e.event_date ASC
");
$events = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EventJoin - Public Events</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            height: 100vh;
        }
        .sidebar {
            width: 220px;
            background: #fff;
            border-right: 1px solid #ccc;
            padding: 20px;
        }
        .sidebar h2 {
            font-size: 24px;
            margin-bottom: 30px;
        }
        .sidebar a {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            text-decoration: none;
            color: #000;
            font-size: 16px;
        }
        .sidebar a i {
            margin-right: 10px;
        }
        .main-content {
            flex-grow: 1;
            overflow-y: auto;
        }
        .hero {
            background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            text-align: center;
            padding: 60px 20px;
        }
        .hero h1 {
            font-size: 36px;
            margin-bottom: 10px;
        }
        .hero p {
            font-size: 18px;
        }
        .events-section {
            padding: 30px;
            text-align: center;
        }
        .events-section h2 {
            margin-bottom: 30px;
        }
        .event-cards {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        .event-card {
            border: 1px solid #ccc;
            border-radius: 8px;
            width: 260px;
            padding: 15px;
            text-align: center;
        }
        .event-card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
            border-radius: 6px;
        }
        .event-card h3 {
            margin-top: 10px;
        }
        .event-card p {
            font-size: 14px;
            margin: 6px 0;
        }
        .btn {
            background-color: #5c6bc0;
            color: white;
            padding: 10px 20px;
            border: none;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
        }
        .footer {
            text-align: center;
            padding: 15px;
            font-size: 12px;
            color: #666;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>EventJoin</h2>
    <a href="#"><i>🔍</i>Browse Events</a>
    <a href="login.php"><i>🔐</i>Login</a>
    <a href="signup.php"><i>🔁</i>Sign-up</a>
    <div class="footer">© All Rights Reserved</div>
</div>

<div class="main-content">
    <div class="hero">
        <h1>Plan Your Next Event Effortlessly</h1>
        <p>Seamlessly Organize and Manage Your Events</p>
    </div>

    <div class="events-section">
        <h2>Upcoming Events</h2>
        <div class="event-cards">
            <?php foreach ($events as $event): ?>
                <div class="event-card">
                    <img src="assets/images/event-placeholder.jpg" alt="Event Image">
                    <h3><?= htmlspecialchars($event['title']) ?></h3>
                    <p><strong>Date:</strong> <?= $event['event_date'] ?> @ <?= date('g:i A', strtotime($event['event_time'])) ?></p>
                    <p><strong>Hall:</strong> <?= htmlspecialchars($event['hall_name']) ?></p>
                    <form method="GET" action="login.php">
                        <input type="hidden" name="redirect" value="registered_user/confirm_public_rsvp.php?event_id=<?= $event['id'] ?>">
                        <button type="submit" class="btn">Register Now</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

</body>
</html>
