<?php
require_once '../config/conn.php';
include '../includes/header.php';
include '../includes/sidebar.php';
// Fetch public & approved events
$stmt = $pdo->query("
    SELECT e.id, e.title, e.description, e.event_date, e.event_time, h.name AS hall_name
    FROM events e
    JOIN halls h ON e.hall_id = h.id
    WHERE e.is_public = 1 AND e.status = 'approved'
    ORDER BY e.event_date ASC
");
$events = $stmt->fetchAll();
?>

<!-- Hero Section -->
<section class="hero">
    <h1 class="display-5 fw-bold">Welcome to EventJoin</h1>
    <p class="lead">Discover upcoming public events and join the fun!</p>
</section>
<div class="main-content flex-grow-1">
    <!-- Event Listings -->
    <div class="container py-5">
        <?php if (count($events) > 0): ?>
            <div class="row">
                <?php foreach ($events as $event): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="event-card">
                            <?php
                                $imagePath = !empty($event['banner_image']) ? 'uploads/' . htmlspecialchars($event['banner_image']) : '../assets/images/630x350.png';
                            ?>
                            <img src="<?= $imagePath ?>" alt="Event Image" class="img-fluid mb-3" style="border-radius: 8px; max-height: 180px; object-fit: cover; width: 100%;">
                            <h5><?= htmlspecialchars($event['title']) ?></h5>
                            <p><strong>Date:</strong> <?= $event['event_date'] ?> @ <?= date('g:i A', strtotime($event['event_time'])) ?></p>
                            <p><strong>Hall:</strong> <?= htmlspecialchars($event['hall_name']) ?></p>
                            <p><?= nl2br(htmlspecialchars($event['description'])) ?></p>
                            <form method="GET" action="login.php">
                                <input type="hidden" name="redirect" value="registered_user/confirm_public_rsvp.php?event_id=<?= $event['id'] ?>">
                                <button type="submit" class="btn btn-primary w-100 mt-2">Regsiter Now</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-center text-muted">No public events are currently available.</p>
        <?php endif; ?>
    </div>
</div>
<?php include '../includes/footer.php'; ?>
