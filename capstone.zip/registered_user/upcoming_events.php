<?php
session_start();
require_once '../config/conn.php';

// Redirect if not logged in or wrong role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'requestor') {
    header("Location: ../login.php");
    exit;
}

include '../includes/header.php';
include '../includes/sidebar.php';

$user_id = $_SESSION['user_id'];

// Fetch upcoming events the user RSVP’d to
$stmt = $pdo->prepare("
    SELECT e.title, e.event_date, e.event_time, e.description, h.name AS hall_name
    FROM event_rsvps r
    JOIN events e ON r.event_id = e.id
    JOIN halls h ON e.hall_id = h.id
    WHERE r.user_id = ? AND e.event_date >= CURDATE()
    ORDER BY e.event_date ASC
");
$stmt->execute([$user_id]);
$events = $stmt->fetchAll();
?>

<div class="main-content">
    <section class="hero">
        <h1 class="display-6 fw-bold">Upcoming Events You've RSVP’d To</h1>
        <p class="lead">Keep track of your confirmed upcoming events.</p>
    </section>

    <div class="container py-4">
        <?php if (count($events) > 0): ?>
            <div class="row">
                <?php foreach ($events as $event): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="event-card">
                            <h5><?= htmlspecialchars($event['title']) ?></h5>
                            <p><strong>Date:</strong> <?= $event['event_date'] ?> @ <?= date('g:i A', strtotime($event['event_time'])) ?></p>
                            <p><strong>Location:</strong> <?= htmlspecialchars($event['hall_name']) ?></p>
                            <p><?= nl2br(htmlspecialchars($event['description'])) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-muted text-center">You haven’t RSVP’d to any upcoming events yet.</p>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
